# Subarray Sum (Code War Chain)

A **progressive** ("Code War") problem: stages unlock one at a time. Each stage
enhances the previous one and reuses the same editor and boilerplate — only the
statement and the test cases change.

1. **Stage 1 - Is k Present?** — target O(n)
2. **Stage 2 - Total Sum** — target O(n)
3. **Stage 3 - Maximum Subarray Sum** — target O(n)
4. **Stage 4 - Count Subarrays Summing To k** — target O(n)
5. **Stage 5 - Longest Such Subarray** — target O(n)
6. **Stage 6 - Shortest Such Subarray** — target O(n)
7. **Stage 7 - Subarrays Divisible By k** — target O(n)

Solve a stage and submit to unlock the next one.
