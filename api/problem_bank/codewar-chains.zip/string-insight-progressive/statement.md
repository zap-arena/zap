# String Insight (Code War Chain)

A **progressive** ("Code War") problem: stages unlock one at a time. Each stage
enhances the previous one and reuses the same editor and boilerplate — only the
statement and the test cases change.

1. **Stage 1 - Is It A Palindrome?** — target O(n)
2. **Stage 2 - Count Distinct Characters** — target O(n)
3. **Stage 3 - Most Frequent Character** — target O(n)
4. **Stage 4 - Longest Substring Without Repeats** — target O(n)
5. **Stage 5 - Longest Run** — target O(n)
6. **Stage 6 - Count Palindromic Substrings** — target O(n^2)
7. **Stage 7 - Longest Palindromic Substring** — target O(n^2)

Solve a stage and submit to unlock the next one.
