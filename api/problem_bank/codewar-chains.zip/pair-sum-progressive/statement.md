# Pair Sum (Code War Chain)

A **progressive** ("Code War") problem: stages unlock one at a time. Each stage
enhances the previous one and reuses the same editor and boilerplate — only the
statement and the test cases change.

1. **Stage 1 - Does a Pair Exist?** — target O(n)
2. **Stage 2 - Locate the Pair** — target O(n)
3. **Stage 3 - Count Every Pair** — target O(n)
4. **Stage 4 - Count Distinct Value Pairs** — target O(n)
5. **Stage 5 - Closest Reachable Sum** — target O(n log n)
6. **Stage 6 - Triplets** — target O(n^2)
7. **Stage 7 - Longest Subarray With The Target Sum** — target O(n)

Solve a stage and submit to unlock the next one.
