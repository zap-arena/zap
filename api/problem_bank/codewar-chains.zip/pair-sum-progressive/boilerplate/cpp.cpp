#include <bits/stdc++.h>
using namespace std;

long long solve(vector<long long>& nums, long long target) {
    // TODO: implement the current stage
    return 0;
}

int main() {
    int n;
    if (!(cin >> n)) return 0;
    vector<long long> nums(n);
    for (auto &x : nums) cin >> x;
    long long target;
    cin >> target;
    cout << solve(nums, target) << endl;
    return 0;
}
