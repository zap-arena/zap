import java.util.*;

public class Main {
    static long solve(long[] nums, long target) {
        // TODO: implement the current stage
        return 0;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        long[] nums = new long[n];
        for (int i = 0; i < n; i++) nums[i] = sc.nextLong();
        long target = sc.nextLong();
        System.out.println(solve(nums, target));
    }
}
