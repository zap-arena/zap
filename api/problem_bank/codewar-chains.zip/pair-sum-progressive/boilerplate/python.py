import sys


def solve(nums, target):
    # TODO: implement the current stage
    return 0


def main():
    data = sys.stdin.read().split()
    n = int(data[0])
    nums = [int(x) for x in data[1:1 + n]]
    target = int(data[1 + n])
    print(solve(nums, target))


if __name__ == "__main__":
    main()
