#include <stdio.h>
#include <stdlib.h>

long solve(long *nums, int n, long target) {
    /* TODO: implement the current stage */
    return 0;
}

int main() {
    int n;
    if (scanf("%d", &n) != 1) return 0;
    long *nums = malloc(sizeof(long) * n);
    for (int i = 0; i < n; i++) scanf("%ld", &nums[i]);
    long target;
    scanf("%ld", &target);
    printf("%ld\n", solve(nums, n, target));
    free(nums);
    return 0;
}
