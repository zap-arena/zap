# Sorted Search (Code War Chain)

A **progressive** ("Code War") problem: stages unlock one at a time. Each stage
enhances the previous one and reuses the same editor and boilerplate — only the
statement and the test cases change.

1. **Stage 1 - Does The Target Exist?** — target O(1)/O(log n)
2. **Stage 2 - First Occurrence** — target O(1)/O(log n)
3. **Stage 3 - Occurrence Count** — target O(1)/O(log n)
4. **Stage 4 - Lower Bound** — target O(1)/O(log n)
5. **Stage 5 - Elements Strictly Below** — target O(1)/O(log n)
6. **Stage 6 - Closest Value** — target O(1)/O(log n)
7. **Stage 7 - Pairs Within A Budget** — target O(n)

Solve a stage and submit to unlock the next one.
