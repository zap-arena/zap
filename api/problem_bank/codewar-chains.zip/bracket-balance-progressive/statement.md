# Bracket Balance (Code War Chain)

A **progressive** ("Code War") problem: stages unlock one at a time. Each stage
enhances the previous one and reuses the same editor and boilerplate — only the
statement and the test cases change.

1. **Stage 1 - Is It Balanced?** — target O(n)
2. **Stage 2 - First Offending Index** — target O(n)
3. **Stage 3 - Maximum Nesting Depth** — target O(n)
4. **Stage 4 - Count Matched Pairs** — target O(n)
5. **Stage 5 - Minimum Insertions To Balance** — target O(n)
6. **Stage 6 - Longest Balanced Substring** — target O(n)
7. **Stage 7 - Count Balanced Substrings** — target O(n)

Solve a stage and submit to unlock the next one.
