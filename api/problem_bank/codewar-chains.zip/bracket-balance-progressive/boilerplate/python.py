import sys


def solve(s):
    # TODO: implement the current stage
    return 0


def main():
    s = sys.stdin.read().strip()
    print(solve(s))


if __name__ == "__main__":
    main()
