import java.util.*;
import java.io.*;

public class Main {
    static String solve(String s) {
        // TODO: implement the current stage
        return "0";
    }

    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String s = br.readLine();
        if (s == null) s = "";
        System.out.println(solve(s.trim()));
    }
}
