#include <stdio.h>
#include <string.h>

#define MAXN 100005
char s[MAXN];

int main() {
    if (scanf("%100000s", s) != 1) return 0;
    /* TODO: implement the current stage */
    printf("0\n");
    return 0;
}
