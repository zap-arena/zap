#include <bits/stdc++.h>
using namespace std;

string solve(const string& s) {
    // TODO: implement the current stage
    return "0";
}

int main() {
    string s;
    getline(cin, s);
    cout << solve(s) << endl;
    return 0;
}
